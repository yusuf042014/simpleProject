Java Batch Install
===================

This Role will pull an artifact from Nexus update config files and push to the target servers.



Requirements
------------

Any pre-requisites that may not be covered by Ansible itself or the role should be mentioned here.
  for instance, if the role uses the EC2 module, it may be a good idea to mention in this section that the boto package is required.
  
  None.
  
Role Variables:
---------------

A description of the settable variables for this role should go here, including any variables that are in defaults/main.yml, vars/main.yml, and any variables that can/should be set via parameters to the role.
Any variables that are read from other roles and/or the global scope (i.e hostvars, group vars, etc) should be mentioned there as well.


*install_path
*enable
*
*

Dependencies
------------
A list of other roles hosted on Galaxy should go here, plus any details in regards to paramerters that may need to be set for other roles, or variables that are used from other roles.

None

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables pass in parameters) is always nice to users too:

    - hosts: servers
	  roles:
	     - { role: username.rolename,
		     app_path: "/opt/correspondence/myapp",
			 app_start_script: "start.sh",
			 app_stop_script: "stop.sh",
			 enable_app_start: "false",
			 disable_app_backup: "true",
			}
			
Author Information
------------------
Kevin Kehres

An optional section for the role authoers to include contact information, or a website (HTML is not allowed).
