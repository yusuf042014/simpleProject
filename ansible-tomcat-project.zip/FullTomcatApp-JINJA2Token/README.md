Ansible Install
===================

ansible.cfg
------------

- Configuration defaults
- see: http://docs.ansible.com/ansible/intro_configuration.html


deploy.yml
----------

- playbook for app
- see: http://docs.ansible.com/ansible/playbook.html


hosts
------

INTI formatted text file of servers to impact

- see: http://docs.ansible.com/ansible/intro_inventory.html